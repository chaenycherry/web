package com.backend.model;

public enum ERole {
    ROLE_USER,
    ROLE_USER_MEMBER,
    ROLE_ADMIN
}
